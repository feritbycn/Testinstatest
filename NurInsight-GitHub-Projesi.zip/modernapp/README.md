# NurInsight — Instagram analiz arayüzü

Modern Android başlangıç projesi; Android Studio / GitHub Actions ile derlenebilir. Arayüz Türkçedir ve küçük ekranlara uyumlu tasarlanmıştır.

## Dahil edilen ekranlar
- Özet paneli ve metrik kartları
- Takipçi/takip edilen, takip etmeyenler ve büyüme analizi için araç menüsü
- Gönderi, hikâye, öne çıkan ve Reels içerik alanları
- Analiz geçmişi, ayarlar ve Pro giriş noktaları
- GitHub Actions ile otomatik debug APK derlemesi

## Önemli kapsam notu
Bu ZIP, yüklenen dosyanın derlenmiş Android APK'sından ayrı, sıfırdan hazırlanmış bir kaynak kod projesidir; orijinal uygulamanın kodunun birebir kopyası değildir. Şu an arayüz ve gezinme iskeleti/demo metrikleri bulunur. Gerçek Instagram verileri, takipçi değişimleri veya hikâye görüntüleme gibi işlevler kendiliğinden çalışmaz. Bunlar için Meta'nın izin verdiği Instagram API kapsamları ya da kullanıcının kendi hesap verilerinin dışa aktarımını içe aktaran bir modül gerekir. Instagram şifresi toplama, oturum çerezi çıkarma veya erişim kontrollerini aşma eklenmemiştir.

## GitHub'da yayınlama
1. ZIP'i açıp içindeki dosyaları yeni bir GitHub deposuna yükleyin.
2. `Actions` sekmesinden `Android APK derle` iş akışını çalıştırın (veya `main` dalına push edin).
3. Tamamlanan çalışmanın `Artifacts` bölümünden `NurInsight-debug-apk` dosyasını indirin.

## Yerelde derleme
Android Studio'da projeyi açın veya JDK 17 ve Android SDK 35 kurulu iken proje klasöründe `gradle assembleDebug` çalıştırın.
